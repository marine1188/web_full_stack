package com.gyun.quiz;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrderVO {
	private int seq ;
	private int cusSeq;
	private String date;
	private List<OrderDetailVO> detail;
	
	public int getCusSeq() {
		return cusSeq;
	}
	public void setCusSeq(int cusSeq) {
		this.cusSeq = cusSeq;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public List<OrderDetailVO> getDetail() {
		return detail;
	}
	public void setDetail(List<OrderDetailVO> detail) {
		this.detail = detail;
	}
	public OrderVO(int seq,int cusSeq,  List<OrderDetailVO> detail) {
		System.out.println("1.detail =  " + detail);
		this.seq=seq;
		this.cusSeq=cusSeq;
		this.date=getOrderDate();
		this.detail=new ArrayList<OrderDetailVO>();
		this.detail.addAll(detail);
	}
	public String getOrderDate() {
		Date date = new Date();
		SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		return sdf.format(date);
	}
	public OrderVO() {
		
	}
	
	@Override
	public String toString() {
		return "����: seq=" + seq + ", cusSeq=" + cusSeq + ", date=" + date + ", detail=" + detail + "\n";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + seq;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderVO other = (OrderVO) obj;
		if (seq != other.seq)
			return false;
		return true;
	}
	
}
