package com.gyun.quiz;

import java.util.List;

public class OrderDetailVO {
	private int amount;
	private int discount;
	private Item item;
	public OrderDetailVO() {
		
	}
	public OrderDetailVO(int amount , int discount,Item item) {
		this.amount=amount;
		this.discount = discount;
		this.item=item;
	}
	
	@Override
	public String toString() {
		return "���ֻ� ��:" + amount + ", ������=" + discount + ", ��ǰ=" + item ;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}
	

	
	
}
