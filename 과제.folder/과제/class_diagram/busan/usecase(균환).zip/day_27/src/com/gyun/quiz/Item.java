package com.gyun.quiz;

public class Item {
	private int seq;
	private String name;
	private int price;
	private int wearHouseSeq;
	private int amount;
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getWearHouseSeq() {
		return wearHouseSeq;
	}
	public void setWearHouseSeq(int wearHouseSeq) {
		this.wearHouseSeq = wearHouseSeq;
	}
	public int getPrice() {
		return price;
	}
	
	@Override
	public String toString() {
		return "��ǰ  ��ǰ��ȣ=" + seq + ", ��ǰ��=" + name + ", ��ǰ����=" + price + ", â����ȣ=" + wearHouseSeq
				+ ",  ���=" + amount + "\n";
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
}
