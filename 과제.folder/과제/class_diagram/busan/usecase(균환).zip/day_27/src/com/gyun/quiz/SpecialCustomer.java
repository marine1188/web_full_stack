package com.gyun.quiz;

public class SpecialCustomer extends Customer {
	private int discount;
	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	@Override
	public int getSeq() {
		// TODO Auto-generated method stub
		return super.getSeq();
	}

	@Override
	public void setSeq(int seq) {
		// TODO Auto-generated method stub
		super.setSeq(seq);
	}

	@Override
	public String toString() {
		return "SpecialCustomer [discount=" + discount + "]";
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return super.getName();
	}

	@Override
	public void setName(String name) {
		// TODO Auto-generated method stub
		super.setName(name);
	}

	@Override
	public String getAddress() {
		// TODO Auto-generated method stub
		return super.getAddress();
	}

	@Override
	public void setAddress(String address) {
		// TODO Auto-generated method stub
		super.setAddress(address);
	}

	@Override
	public String getTel() {
		// TODO Auto-generated method stub
		return super.getTel();
	}

	@Override
	public void setTel(String tel) {
		// TODO Auto-generated method stub
		super.setTel(tel);
	}
	
}
