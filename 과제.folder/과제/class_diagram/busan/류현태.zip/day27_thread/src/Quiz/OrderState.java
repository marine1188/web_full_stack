package Quiz;
//���ָ���
public class OrderState extends ProductVO{
	int orderCount;
	int discount;
	public int getOrderCount() {
		return orderCount;
	}
	public void setOrderCount(int orderCount) {
		this.orderCount = orderCount;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	
	public OrderState(int orderCount,int discount,int productNum) {
		// TODO Auto-generated constructor stub
		super.setProductNum(productNum);
		this.orderCount=orderCount;
		this.discount=discount;
	}
	
}
