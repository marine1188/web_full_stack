package Quiz;
//Ư��ȸ��
public class VipCustomer {
	boolean vip;

	public boolean isVip() {
		return vip;
	}

	public void setVip(boolean vip) {
		this.vip = vip;
	}

	@Override
	public String toString() {
		return "VipCustomer [vip=" + vip + "]";
	}
	
}
