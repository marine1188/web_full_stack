package Quiz;

//����
public class CustomerVO extends VipCustomer {
	int customerNum;
	String customerName;
	String customerAddress;
	String customerPhone;

	public int getCustomerNum() {
		return customerNum;
	}

	public void setCustomerNum(int customerNum) {
		this.customerNum = customerNum;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	@Override
	public String toString() {
		return "CustomerVO [customerNum=" + customerNum + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", customerPhone=" + customerPhone + ", vip=" + vip + "]";
	}

	public CustomerVO(int customerNum, String customerName, String customerAddress, String customerPhone) {
		// TODO Auto-generated constructor stub
		this.customerNum=customerNum;
		this.customerName=customerName;
		this.customerAddress=customerAddress;
		this.customerPhone=customerPhone;
	}

}
