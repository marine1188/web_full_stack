package Quiz;
//���
public class StockVO {
	int stockCount;

	public int getStockCount() {
		return stockCount;
	}

	public void setStockCount(int stockCount) {
		this.stockCount = stockCount;
	}
	
}
