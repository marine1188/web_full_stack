package Quiz;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;

public class OrderUi {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		HashMap<ProductVO, WareVO> pw = new HashMap<ProductVO, WareVO>();
		ConcurrentHashMap<Order, CustomerVO> oc = new ConcurrentHashMap<Order, CustomerVO>();
		CustomerVO customer = null;
		addpw(pw);
		for (;;) {
			System.out.println("1.���������Է� 2.���ֵ�� 3.������� 4.��� 5.����");
			int num = scan.nextInt();
			switch (num) {
			case 1:
				customer = add(scan);
				break;
			case 2:
				order(scan, oc, pw, customer);
				break;
			case 3:
				cancel(scan, oc, pw);
				break;
			case 4:
				print(scan, oc, pw);
				break;
			case 5:
				System.exit(0);
				break;
			default:
				break;
			}
		}
	}

	static void addpw(HashMap<ProductVO, WareVO> pw) {

		ProductVO pv;
		WareVO wv;
		for (int i = 1; i < 10; i++) {
			pv = new ProductVO();
			wv = new WareVO();
			pv.setProductName("" + i);
			pv.setProductNum(i);
			pv.setProductPrice(i);
			pv.setStockCount(i);
			wv.setWareAddress("" + i);
			wv.setWareName("" + i);
			wv.setWarePhone("" + i);
			pw.put(pv, wv);
		}

	}

	static CustomerVO add(Scanner scan) {

		int customerNum;
		String customerName;
		String customerAddress;
		String customerPhone;

		System.out.print("������ȣ");
		customerNum = scan.nextInt();
		System.out.print("�����̸�");
		customerName = scan.next();
		System.out.print("�����ּ�");
		customerAddress = scan.next();
		System.out.print("������ȭ��ȣ");
		customerPhone = scan.next();

		CustomerVO customer = new CustomerVO(customerNum, customerName, customerAddress, customerPhone);

		return customer;
	}

	static void order(Scanner scan, ConcurrentHashMap<Order, CustomerVO> oc, HashMap<ProductVO, WareVO> pw,
			CustomerVO customer) {

		String yn;

		int orderNum;

		int orderCount;
		int discount;

		int productNum;

		System.out.print("�ֹ���ȣ");
		orderNum = scan.nextInt();
		for (;;) {
			System.out.print("��ǰ��ȣ");
			productNum = scan.nextInt();
			System.out.print("�ֹ�����");
			orderCount = scan.nextInt();
			System.out.print("������");
			discount = scan.nextInt();

			Order ex = new Order(discount, orderCount, orderNum, productNum);

			oc.put(ex, customer);
			Iterator<Entry<ProductVO, WareVO>> entries = pw.entrySet().iterator();
			while (entries.hasNext()) {
				Entry<ProductVO, WareVO> entry = entries.next();
				if (entry.getKey().getProductNum() == productNum) {
					entry.getKey().setStockCount(entry.getKey().getStockCount() - orderCount);
				}
			}
			System.out.println("�߰��ֹ� 1.y 2.n");
			yn = scan.next();
			if (yn.equals("n")) {
				break;
			}
		}

	}

	static void cancel(Scanner scan, ConcurrentHashMap<Order, CustomerVO> oc, HashMap<ProductVO, WareVO> pw) {
		System.out.println("����� �ֹ���ȣ");
		int num = scan.nextInt();

		for (Order i : oc.keySet()) {
			if (i.getOrderNum() == num) {
				Iterator<Entry<ProductVO, WareVO>> entries2 = pw.entrySet().iterator();

				while (entries2.hasNext()) {
					Entry<ProductVO, WareVO> entry = entries2.next();
					if (entry.getKey().getProductNum() == i.getProductNum()) {
						entry.getKey().setStockCount(entry.getKey().getStockCount() + i.getOrderCount());
					}
				}
				oc.remove(i);
			}

		}
	}

	static void print(Scanner scan, ConcurrentHashMap<Order, CustomerVO> oc, HashMap<ProductVO, WareVO> hm) {
		int num;
		System.out.println("1.�ֹ� 2.���");
		num = scan.nextInt();
		switch (num) {
		case 1:
			Iterator<Entry<Order, CustomerVO>> entries1 = oc.entrySet().iterator();
			System.out.println("1.�ֹ���ȣ\t2.�ֹ���¥\t\t\t3.�ֹ�����\t4.������\t5.��ǰ��ȣ\t6.������ȣ\t7.�����̸�\t8.�����ּ�\t9.������ȭ��ȣ");
			while (entries1.hasNext()) {
				Entry<Order, CustomerVO> entry = entries1.next();
				System.out.print(entry.getKey().getOrderNum() + "\t");
				System.out.print(entry.getKey().getOrderDate() + "\t");
				System.out.print(entry.getKey().getOrderCount() + "\t");
				System.out.print(entry.getKey().getDiscount() + "\t");
				System.out.print(entry.getKey().getProductNum() + "\t");
				System.out.print(entry.getValue().getCustomerNum() + "\t");
				System.out.print(entry.getValue().getCustomerName() + "\t");
				System.out.print(entry.getValue().getCustomerAddress() + "\t");
				System.out.println(entry.getValue().getCustomerPhone() + "\t");
			}
			break;

		case 2:
			Iterator<Entry<ProductVO, WareVO>> entries2 = hm.entrySet().iterator();
			System.out.println("1.��ǰ��ȣ\t2.��ǰ��\t3.��ǰ����\t4.����\t5.â���̸�\t6.â���ּ�\t7.â����ȭ��ȣ");
			while (entries2.hasNext()) {
				Entry<ProductVO, WareVO> entry = entries2.next();
				System.out.print(entry.getKey().getProductNum() + "\t");
				System.out.print(entry.getKey().getProductName() + "\t");
				System.out.print(entry.getKey().getProductPrice() + "\t");
				System.out.print(entry.getKey().getStockCount() + "\t");
				System.out.print(entry.getValue().getWareName() + "\t");
				System.out.print(entry.getValue().getWareAddress() + "\t");
				System.out.println(entry.getValue().getWarePhone() + "\t");
			}
			break;
		default:
			break;
		}

	}
}
