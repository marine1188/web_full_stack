package Quiz;
//â��
public class WareVO {
	
	String wareName;
	String wareAddress;
	String warePhone;
	
	public String getWareName() {
		return wareName;
	}
	public void setWareName(String wareName) {
		this.wareName = wareName;
	}
	public String getWareAddress() {
		return wareAddress;
	}
	public void setWareAddress(String wareAddress) {
		this.wareAddress = wareAddress;
	}
	public String getWarePhone() {
		return warePhone;
	}
	public void setWarePhone(String warePhone) {
		this.warePhone = warePhone;
	}
	
}
