package Quiz;

import java.text.SimpleDateFormat;
import java.util.Date;

//����
public class Order extends OrderState{
	int orderNum;
	String orderDate;
	public int getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	@Override
	public String toString() {
		return "Order [orderNum=" + orderNum + ", orderDate=" + orderDate + "]";
	}
	
	public Order(int discount,int orderCount,int orderNum,int productNum) {
		// TODO Auto-generated constructor stub
		super(orderCount, discount,productNum);
		this.orderNum=orderNum;
		today();
	}
	
	public void today() {
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date time = new Date();
		String time1 = format1.format(time);
		this.orderDate=time1;
	}
	
}
