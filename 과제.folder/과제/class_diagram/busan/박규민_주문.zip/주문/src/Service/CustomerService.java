package Service;

import java.util.ArrayList;
import java.util.List;

import vo.Customer;
import vo.SpecialCustomer;

public class CustomerService {
	private List<Customer> customerList;

	public List<Customer> getCustomerList() {
		return customerList;
	}

	public void setCustomerList(List<Customer> customerList) {
		this.customerList = customerList;
	}

	public CustomerService() {
		customerList = new ArrayList<Customer>();
		defaultDataSet();
	}

	public Customer find(int cunstomerNum) {
		for (Customer item : customerList) {
			if (item.getNum() == cunstomerNum) {
				return item;
			}
		}
		return null;
	}

	public void add(String name, String address, String phoneNumber) {
		Customer customer = new Customer();
		customer.setName(name);
		customer.setNum();
		customer.setPhoneNumber(phoneNumber);
		customer.setAddress(address);

		customerList.add(customer);
	}

	public void SpecialCustomerAdd(String name, String address, String phoneNumber) {
		Customer specialCustomer = new SpecialCustomer();

		specialCustomer.setName(name);
		specialCustomer.setNum();
		specialCustomer.setPhoneNumber(phoneNumber);
		specialCustomer.setAddress(address);

		customerList.add(specialCustomer);
	}

	public void defaultDataSet() {
		add("�����", "�λ� ������", "010-1111-1111");
		add("���ϼ�", "�λ� �ϱ�", "010-2222-1111");
		add("���߼�", "�λ� ����", "010-3333-1111");
		add("�̵���", "�λ� �ؿ�뱸", "010-4444-1111");
	}

}
