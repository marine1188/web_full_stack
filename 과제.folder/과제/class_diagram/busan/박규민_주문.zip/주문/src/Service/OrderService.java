package Service;

import java.util.ArrayList;
import java.util.List;

import vo.Customer;
import vo.Order;
import vo.Orders;

public class OrderService {

	private Order order;

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public void Register(OrdersService ordersService, Customer customer) {
		order = new Order();
		order.setOrdersList(ordersService.getOrdersList());

		// ���ָ��� �ʱ�ȭ
		ordersService.setOrdersList(new ArrayList<Orders>());
		order.setCustomer(customer);
		order.setDate();

	}

	public boolean Cancel() {
		// TODO Auto-generated method stub
		order = null;
		return false;
	}

	

}
