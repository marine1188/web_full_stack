package Service;

import java.util.ArrayList;
import java.util.List;

import vo.Order;
import vo.Orders;
import vo.Product;

public class OrdersService {

	private List<Orders> ordersList;

	public OrdersService() {
		setOrdersList(new ArrayList<Orders>());
	}
	

	public List<Orders> getOrdersList() {
		return ordersList;
	}

	public void setOrdersList(List<Orders> ordersList) {
		this.ordersList = ordersList;
	}
	

	public boolean add(Product product, int quantity, int discountRate) {
		
		if(product.getQuantity() < quantity ) return false;
		
		product.setQuantity(product.getQuantity()-quantity);
		Orders orders = new Orders();
		orders.setProduct(product);
		orders.setQuantity(quantity);
		orders.setDiscountRate(discountRate);
		orders.setOrdersPrice();
		
		ordersList.add(orders);
		
		return true;
	}
	
	public boolean Cancel(int num) {
		// TODO Auto-generated method stub
		for (Orders item : ordersList) {
			if (item.getProduct().getNum() == num) {
				item.getProduct().setQuantity(item.getProduct().getQuantity()+item.getQuantity());
				ordersList.remove(item);
				return true;
			}
		}
		return false;
	}




}
