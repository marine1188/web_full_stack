package Service;

import java.util.ArrayList;
import java.util.List;

import vo.Product;

public class ProductService {
	private List<Product> productList;

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}
	public ProductService() {
		setProductList(new ArrayList<Product>());
		defaultDataSet();
	}
	
	public void productAdd(String warehouseName, String warehouseAddress, String warehouseCallNumber, String name, int price, int quantity) {
		Product product= new Product();
		
		product.setPrice(price);
		product.setName(name);
		product.setNum();
		product.setQuantity(quantity);
		product.setWarehouseCallNumber(warehouseCallNumber);
		product.setWarehouseAddress(warehouseAddress);;
		product.setWarehouseName(warehouseName);
		productList.add(product);
	}
	
	public Product find(int num) {
		for (Product item : productList) {
			if (item.getNum() == num) {
				return item;
			}
		}
		return null;
	}
	
	public void defaultDataSet() {
		productAdd("Aâ��", "�����", "051-000-0111", "���", 3000, 10);
		productAdd("Bâ��", "����", "051-000-0222", "�ٳ���", 2000, 20);
		productAdd("Câ��", "�ν�", "051-000-0333", "����", 5000, 15);
		productAdd("Dâ��", "����", "051-000-0444", "����", 2000, 30);
	}

	
}
