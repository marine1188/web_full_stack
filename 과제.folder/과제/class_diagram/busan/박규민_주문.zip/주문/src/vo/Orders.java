package vo;

public class Orders {

	private Product product;
	private int quantity;
	private int discountRate;
	private int ordersPrice;
	

	
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(int discountRate) {
		this.discountRate = discountRate;
	}
	public int getOrdersPrice() {
		return ordersPrice;
	}

	public void setOrdersPrice() {

		this.ordersPrice = (int)((double)(quantity * product.getPrice()) * (double) (100 - discountRate) / 100);
	}

	@Override
	public String toString() {
		return product + "\t\t\t���ּ��� = " + quantity + " ��\t\t���η� = " + discountRate + "%"+ " \t\t���� �ݾ� = " + ordersPrice + "��";
	}

	

}
