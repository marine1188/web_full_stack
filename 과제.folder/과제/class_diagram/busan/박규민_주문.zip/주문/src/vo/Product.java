package vo;

public class Product{
	
	private String warehouseName;
	private String warehouseAddress;
	private String warehouseCallNumber;
	private static int productseq=0;
	private int num;
	private String name;
	private int price;
	private int quantity;
	
	public String getWarehouseName() {
		return warehouseName;
	}
	public void setWarehouseName(String warehouseName) {
		this.warehouseName = warehouseName;
	}
	public int getNum() {
		return num;
	}
	public void setNum() {
		this.num = ++productseq;
	}
	
	public String getWarehouseAddress() {
		return warehouseAddress;
	}
	public void setWarehouseAddress(String warehouseAddress) {
		this.warehouseAddress = warehouseAddress;
	}
	public String getWarehouseCallNumber() {
		return warehouseCallNumber;
	}
	public void setWarehouseCallNumber(String warehouseCallNumber) {
		this.warehouseCallNumber = warehouseCallNumber;
	}
	public static int getProductseq() {
		return productseq;
	}
	public static void setProductseq(int productseq) {
		Product.productseq = productseq;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "��ǰ�ڵ�=" + num + "\t\t��ǰ�� = " + name + "\t\t�ܰ� = " + price + "��\t\t������� = " + quantity + " ��\n";
	}
	
	

}
