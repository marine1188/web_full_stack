package vo;

public class SpecialCustomer extends Customer{

	private static int specialCustomerSeq = 0;
	
	private int num;

	public int getNum() {
		return num;
	}

	public void setNum() {
		this.num = ++specialCustomerSeq;
	}

	
	
	

	
}
