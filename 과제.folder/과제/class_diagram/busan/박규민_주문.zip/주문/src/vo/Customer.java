package vo;

public class Customer {

	private static int customerSeq = 0;
	private int num;
	private String name;
	private String address;
	private String phoneNumber;

	public int getNum() {
		return num;
	}

	public void setNum() {
		this.num = ++customerSeq;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	
	@Override
	public String toString() {
		return "������ȣ=" + num + "\t������=" + name + "\t     �ּ�=" + address + "\t    ��ȭ��ȣ=" + phoneNumber + "\n";
	}

	

}
