package vo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Order {

	private String date;
	private List<Orders> ordersList;
	private Customer customer;
	
	private int totalprice = 0;


	public String getDate() {
		return date;
	}

	public void setDate() {
		this.date = getOrderDate();
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public String getOrderDate() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd-hh:mm:ss");
		return sdf.format(date);
	}
	
	public int getTotalprice() {
		return totalprice;
	}

	public void setTotalprice(int totalprice) {
		this.totalprice += totalprice;
	}
	
	public List<Orders> getOrdersList() {
		return ordersList;
	}

	public void setOrdersList(List<Orders> ordersList) {
		this.ordersList = ordersList;
	}

	@Override
	public String toString() {
		String temp = "\n\n\n*****************************************��������*****************************************\n"
				+ "\t\t\t\t\t\t\t    ���ֳ�¥ : " + date + "\n���� : " + customer
				+ "\n\n****************************************���ָ���Ʈ****************************************\n";
		for (Orders item : ordersList) {
			setTotalprice(item.getOrdersPrice());
			temp += item + "\n-------------------------------------------------------------------------------------------\n";
			
		}
		temp += "\t\t\t\t\t\t\t\t\t�� ������:  " + getTotalprice() + "��\n\n\n";
		return temp;
	}

	

	

	

	

}
