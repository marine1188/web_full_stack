package order;

import java.io.Serializable;

public class WareHouse implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String housenm, houseaddr, housetel;
	private Item item;

	public String getHousenm() {
		return housenm;
	}

	public void setHousenm(String housenm) {
		this.housenm = housenm;
	}

	public String getHouseaddr() {
		return houseaddr;
	}

	public void setHouseaddr(String houseaddr) {
		this.houseaddr = houseaddr;
	}

	public String getHousetel() {
		return housetel;
	}

	public void setHousetel(String housetel) {
		this.housetel = housetel;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	@Override
	public String toString() {
		return "WareHouse [housenm=" + housenm + ", houseaddr=" + houseaddr + ", housetel=" + housetel + "]";
	}	
	
	
}
