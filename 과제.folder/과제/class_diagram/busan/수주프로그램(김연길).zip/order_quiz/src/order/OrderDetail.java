package order;

import java.io.Serializable;

public class OrderDetail implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private int qty, sum;
	private String sale_ratio, itemcd, itemnm;

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public String getSale_ratio() {
		return sale_ratio;
	}

	public void setSale_ratio(String sale_ratio) {
		this.sale_ratio = sale_ratio;
	}

	public String getItemcd() {
		return itemcd;
	}

	public void setItemcd(String itemcd) {
		this.itemcd = itemcd;
	}

	public int getSum() {
		return sum;
	}

	public void setSum(int sum) {
		this.sum = sum;
	}

	public String getItemnm() {
		return itemnm;
	}

	public void setItemnm(String itemnm) {
		this.itemnm = itemnm;
	}
	
	
}
