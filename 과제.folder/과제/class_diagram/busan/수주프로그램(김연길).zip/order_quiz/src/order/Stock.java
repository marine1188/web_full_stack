package order;

import java.io.Serializable;

public class Stock extends WareHouse implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int stkqty;

	public int getStkqty() {
		return stkqty;
	}

	public void setStkqty(int stkqty) {
		this.stkqty = stkqty;
	}

	@Override
	public String toString() {
		return "Stock [" + "warehouse=" + getHousenm() + ", " + getHouseaddr() + ", " + getHousetel() + " | item="
				+ getItem().getItemcd() + ", " + getItem().getItemnm() + ", " + getItem().getPrice() + " | " + "stkqty="
				+ stkqty + "]";
	}

}
