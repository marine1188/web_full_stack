package order;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Order implements Serializable {

	private static final long serialVersionUID = 1L;
	private String orddate, ordnum;
	private char registate = ' ';

	private Customer cus = new Customer();
	private ArrayList<OrderDetail> dlist = new ArrayList<OrderDetail>();

	public Order() {
		setOrddate();
	}

	public String getOrdnum() {
		return ordnum;
	}

	public void setOrdnum(String ordnum) {
		this.ordnum = ordnum;
	}

	public Customer getCus() {
		return cus;
	}

	public void setCus(Customer cus) {
		this.cus = cus;
	}

	public ArrayList<OrderDetail> getDetail() {
		return dlist;
	}

	public void setDetail(ArrayList<OrderDetail> dlist) {
		this.dlist = dlist;
	}

	public char getRegistate() {
		return registate;
	}

	public void setRegistate(char registate) {
		this.registate = registate;
	}

	private void setOrddate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		this.orddate = sdf.format(date);
	}

	@Override
	public String toString() {
		String ordInfo = "��������\n" + "���ֹ�ȣ = " + ordnum + " ���ֳ�¥ = " + orddate + " ������ = " + cus.getCustnm() + "(" + cus.getSpcode() + ")" + "\n" ;
		for (OrderDetail items : dlist) {
			ordInfo += "ǰ���ڵ� = " + items.getItemcd() + "("+ items.getItemnm() +") ���� = " + items.getQty() + "�� ������ = " + items.getSale_ratio()
					+ " �� �ݾ� = " + items.getSum() + "\n";
		}
		return ordInfo;
	}

}
