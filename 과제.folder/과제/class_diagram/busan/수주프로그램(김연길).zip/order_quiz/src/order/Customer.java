package order;

import java.io.Serializable;

public class Customer implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String custcd, custnm, custaddr, custtel;
	private char spcode;

	public String getCustcd() {
		return custcd;
	}

	public void setCustcd(String custcd) {
		this.custcd = custcd;
	}

	public String getCustnm() {
		return custnm;
	}

	public void setCustnm(String custnm) {
		this.custnm = custnm;
	}

	public String getCustaddr() {
		return custaddr;
	}

	public void setCustaddr(String custaddr) {
		this.custaddr = custaddr;
	}

	public String getCusttel() {
		return custtel;
	}

	public void setCusttel(String custtel) {
		this.custtel = custtel;
	}

	public char getSpcode() {
		return spcode;
	}

	public void setSpcode(char spcode) {
		this.spcode = spcode;
	}

	@Override
	public String toString() {
		return "Customer [custcd=" + custcd + ", custnm=" + custnm + "(" + spcode + ")" + ", custaddr=" + custaddr
				+ ", custtel=" + custtel + "]";
	}

}
