package day_27_subject;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;

public class ModelProductCount {

	ArrayList<ArrayList> ProductsCount = new ArrayList<ArrayList>();
	ArrayList<ArrayList> RemoveProductsCount = new ArrayList<ArrayList>();
	int Productcode; // ��ǰ �����ڵ�
	String name; // ��ǰ �̸�
	int count; // ��ǰ �� ��������

	// �ʱ�ȭ
	public ModelProductCount() throws IOException, ClassNotFoundException, StreamCorruptedException {
		boolean flag = true;
		File f = new File("productCount.txt");
		FileInputStream fis = null;
		ObjectInputStream bis = null;

		if (f.exists()) {
			try {
				fis = new FileInputStream(f);
				bis = new ObjectInputStream(fis);

				while (flag) {
					ArrayList temp = (ArrayList) bis.readObject();

					ProductsCount.add(temp);
					System.out.println();
				}

			} catch (EOFException e) {
				// ������ ���� �����ϸ� EOFException�� �߻�.
				// �� ���ܸ� ó�����ָ� ���������� ó���˴ϴ�!
				System.out.println();
				System.out.println("Success ProductCount File!");
			} finally {

				bis.close();
			} // try end
		}
		 flag = true;
		 f = new File("ProductsCountRemove.txt");
		 fis = null;
		 bis = null;

		if (f.exists()) {
			try {
				fis = new FileInputStream(f);
				bis = new ObjectInputStream(fis);

				while (flag) {
					ArrayList temp = (ArrayList) bis.readObject();

					RemoveProductsCount.add(temp);
					System.out.println();
				}

			} catch (EOFException e) {
				// ������ ���� �����ϸ� EOFException�� �߻�.
				// �� ���ܸ� ó�����ָ� ���������� ó���˴ϴ�!
				System.out.println();
				System.out.println("Success productCountRemove File!");
			} finally {

				bis.close();
			} // try end
		}
	}

	public void ProductCountSave() throws IOException, ClassNotFoundException {

		if (ProductsCount.size() > 0) {
			System.out.println("��ǰ ��ü ���� ������");
			new Controller().FileAdd("productCount.txt", ProductsCount);

		}
		if (RemoveProductsCount.size() > 0) {
			System.out.println("��ǰ ��ü ���� ���� ������");
			new Controller().FileAdd("ProductsCountRemove.txt", RemoveProductsCount);

		}

	}

	// ��ü ��ǰ���� ���
	public void add(int productCode2, String productName, int productCount2) {
		ArrayList temp = new ArrayList();
		if (ProductsCount.size() == 0) {
			temp.add(productCode2);
			temp.add(productName);
			temp.add(productCount2);
			ProductsCount.add(temp);
		} else {
			int check = 1;
			for (int i = 0; i < ProductsCount.size(); i++) {
				if (ProductsCount.get(i).get(0).equals(productCode2)) {
//					System.out.println("����");
					temp.add(productCode2);
					temp.add(productName);
					temp.add(productCount2+(int)ProductsCount.get(i).get(2));
					ProductsCount.set(i, temp);
					break;
				} else {
					check = 2;
				}

			}
			if (check == 2) {
//				System.out.println("����2");
				temp.add(productCode2);
				temp.add(productName);
				temp.add(productCount2);
				ProductsCount.add(temp);
			}
		}
		

	}

	// ProductsCount ��ȯ
	public ArrayList get() {
		// TODO Auto-generated method stub
	
			return ProductsCount;
		
	}
// ��ǰ ������ �����Ǹ� ����Ǵ��Լ�
	public void update(int code, int sujucount) {
		for (int i = 0; i < ProductsCount.size(); i++) {
			if((int)((ArrayList)ProductsCount.get(i)).get(0) == code) {
				if((int)((ArrayList)ProductsCount.get(i)).get(2)-sujucount ==0) {
					RemoveProductsCount.add(ProductsCount.remove(i));
				}
				else {
					((ArrayList)ProductsCount.get(i)).set(2,(int)((ArrayList)ProductsCount.get(i)).get(2)-sujucount);
				}
//				System.out.println("ī��Ʈ������" +ProductsCount.size());
			}
		}
		
	}

	public void update2(int code, int sujucount) {
		for (int i = 0; i < ProductsCount.size(); i++) {
			if((int)((ArrayList)ProductsCount.get(i)).get(0) == code) {
				if((int)((ArrayList)ProductsCount.get(i)).get(2)+sujucount ==0) {
					RemoveProductsCount.add(ProductsCount.remove(i));
				}
				else {
					((ArrayList)ProductsCount.get(i)).set(2,(int)((ArrayList)ProductsCount.get(i)).get(2)+sujucount);
				}
//				System.out.println("ī��Ʈ������" +ProductsCount.size());
			}
		}
		
	}
}
