package day_27_subject;

import java.io.IOException;
import java.io.StreamCorruptedException;
import java.util.Scanner;

public class MainEntry {
	public static void main(String[] args) throws StreamCorruptedException, ClassNotFoundException, IOException {
	
	View c = new View();
	c.LoginPrint();
	}
}
