package day_27_subject;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;

public class ModelWarehouse {

	private ArrayList<ArrayList> Warehouse = new ArrayList<ArrayList>();
	private int no = 0; // â�� ������ȣ
	private String name; // â�� �̸�
	private String addr; // â�� �ּ�
	private String phone; // â�� ����ó
	private ArrayList productCodes; // â���� �������� ��ǰ��

///â�� �ʱ�ȭ + �޸��� ������ �ҷ�����
	public ModelWarehouse() throws IOException, ClassNotFoundException, StreamCorruptedException {
		boolean flag = true;
		File f = new File("warehouse.txt");
		FileInputStream fis = null;
		ObjectInputStream bis = null;

		if (f.exists()) {
			try {
				fis = new FileInputStream(f);
				bis = new ObjectInputStream(fis);

				while (flag) {
					ArrayList temp = (ArrayList) bis.readObject();
					no = (int) temp.get(0);

					Warehouse.add(temp);

				}

			} catch (EOFException e) {
				// ������ ���� �����ϸ� EOFException�� �߻�.
				// �� ���ܸ� ó�����ָ� ���������� ó���˴ϴ�!
				System.out.println();
				System.out.println("Success warehouse File!");
			} finally {
				no++;
				bis.close();
			} // try end
		}
	}

//â�� ������ �޸��忡 ���� 
	public void WarehouseSave() throws IOException, ClassNotFoundException {

		if (Warehouse.size() > 0) {
			System.out.println("â�� ������");
			new Controller().FileAdd("warehouse.txt", Warehouse);

		}

	}

	// â�����
	public void WarehouseAdd(String name, String addr, String phone) {
		ArrayList temp = new ArrayList();
		temp.add(no);
		temp.add(name);
		temp.add(addr);
		temp.add(phone);
		Warehouse.add(temp);
		System.out.println(no);
		no++;
	}

	// â���ȿ� ������ǰ�߰�
	public void WarehouseProductAdd(int warehouseCode, int productCode, String productName, int productprice,
			int productCount) {

		boolean flag = true;
		for (int i = 0; i < Warehouse.size(); i++) {

			ArrayList temp = new ArrayList();
			if ((int) Warehouse.get(i).get(0) == warehouseCode) {
				
				if (Warehouse.get(i).size() < 5) {
				
					productCodes = new ArrayList();
					Warehouse.get(i).add(productCodes);
					temp.add(productCode);
					temp.add(productName);
					temp.add(productprice);
					temp.add(productCount);

					((ArrayList) Warehouse.get(i).get(4)).add(temp);

				} else  {
			
					ArrayList select = (ArrayList) Warehouse.get(i).get(4);
					int check = 1;

					for (int j = 0; j < select.size(); j++) {

						if ((int) ((ArrayList) select.get(j)).get(0) == productCode) {
							
							((ArrayList) select.get(j)).set(1, productName);
							((ArrayList) select.get(j)).set(2, productprice);
							((ArrayList) select.get(j)).set(3, productCount + (int) ((ArrayList) select.get(j)).get(3));

//							temp.add(productName);
//							temp.add(productprice);
//							temp.add(productCount + (int) ((ArrayList) select.get(j)).get(3));
//							productCodes.set(j, temp);
							((ArrayList) Warehouse.get(i)).set(4, select);
							System.out.println(Warehouse.size());
							check = 1;
							break;
						} else if ((int) ((ArrayList) select.get(j)).get(0) != productCode) {
							
							check = 2;
						}

					}
					
					if (check == 2) {
						
						temp.add(productCode);
						temp.add(productName);
						temp.add(productprice);
						temp.add(productCount);

						((ArrayList) Warehouse.get(i).get(4)).add(temp);
					}
				}
				flag = false;
			}
			
		

		}
		if (flag) {
			System.out.println("����6");
			for (int i = 0; i < Warehouse.size(); i++) {
				if (Warehouse.get(i).size() > 4) {
					ArrayList select = (ArrayList) Warehouse.get(i).get(4);

					for (int j = 0; j < select.size(); j++) {
						if ((int) ((ArrayList) (select).get(j)).get(0) == productCode) {
							((ArrayList) select.get(j)).set(1, productName);
							((ArrayList) select.get(j)).set(2, productprice);
						}
					}
				}
			}

		}
		// �ٸ� â������ ��ǰ�������� �ֽ�ȭ

	}

//â�� ������ ��� 
	public void InfoDetail() {

		System.out.println();
		System.out.println();
		System.out.println(
				"=================================================================================================================================================================");

		System.out.printf("== %75s â������ %71s==\n", " ", " ");
		for (int i = 0; i < Warehouse.size(); i++) {
			int wno = (int) Warehouse.get(i).get(0);
			name = (String) Warehouse.get(i).get(1);
			addr = (String) Warehouse.get(i).get(2);
			phone = (String) Warehouse.get(i).get(3);
			ArrayList Products = new ArrayList();
			System.out.println(
					"=================================================================================================================================================================");
			System.out.printf("%10s %20s %20s %15s \n", "��ȣ", "â���̸�", "�ּ�", "����ó");

			System.out.println(
					"=================================================================================================================================================================");

			if (Warehouse.get(i).size() > 4) {
				Products = (ArrayList) Warehouse.get(i).get(4);
			}
			System.out.printf("%10s %20s %20s %20s\n", wno, name, addr, phone);

			if (Products.size() == 0) {

				System.out.println("\n");
				System.out.println(
						"=================================================================================================================================================================");
				System.out.printf("%80s\n", "�������� ��ǰ ����");
				System.out.println();
			} else {
				System.out.println(
						"=================================================================================================================================================================");
				System.out.printf("%10s %20s %20s %15s \n", "��ǰ�ڵ�", "��ǰ�̸�", "����", "����");
				System.out.println(
						"=================================================================================================================================================================");
				
				for (int j = 0; j < Products.size(); j++) {

					System.out.printf("%10s %20s %20s %15s \n", ((ArrayList<ArrayList>) Products.get(j)).get(0),
							((ArrayList<ArrayList>) Products.get(j)).get(1),
							((ArrayList<ArrayList>) Products.get(j)).get(2),
							((ArrayList<ArrayList>) Products.get(j)).get(3));

				}

			}
			System.out.println("\n");

			System.out.println();
			System.out.println();

		}

		System.out.println();
		System.out.println();
	}

//â�������� ��� 
	public void Info() {

		System.out.println(
				"=================================================================================================================================================================");

		System.out.printf("== %75s â������ %71s==\n", " ", " ");
		System.out.printf("%10s %20s %20s %15s \n", "��ȣ", "â���̸�", "�ּ�", "����ó");

		System.out.println(
				"=================================================================================================================================================================");

		for (int i = 0; i < Warehouse.size(); i++) {
			int wno = (int) Warehouse.get(i).get(0);
			name = (String) Warehouse.get(i).get(1);
			addr = (String) Warehouse.get(i).get(2);
			phone = (String) Warehouse.get(i).get(3);
			System.out.printf("%10s %20s %20s %15s \n", wno, name, addr, phone);

		}

	}

// â���� �����ڵ�� â�� �ߺ����� üũ
	public boolean getWarehouse(int warehouseCode) {

		for (int i = 0; i < Warehouse.size(); i++) {
			if ((int) Warehouse.get(i).get(0) == warehouseCode) {
				return false;
			}
		}
		return true;
	}

// â���� ������ ��ǰ�� �ߺ��� ��ǰ���ִ��� üũ
	public boolean getWarehouseProductCode(int warehouseCode, int productCode) {
		for (int i = 0; i < Warehouse.size(); i++) {
			if ((int) Warehouse.get(i).get(0) == warehouseCode) {
				if (Warehouse.get(i).size() > 4) {
					for (int j = 0; j < ((ArrayList) Warehouse.get(i).get(4)).size(); j++) {
						if ((int) (((ArrayList<ArrayList>) Warehouse.get(i).get(4)).get(j).get(0)) == productCode) {
							return true;
						}

					}
				}

			}
		}
		return false;
	}

//â���� �̸����� â�� �ߺ�����üũ
	public boolean getWarehouse2(String warehouseName) {
		for (int i = 0; i < Warehouse.size(); i++) {
			if (Warehouse.get(i).get(1).equals(warehouseName)) {
				return true;
			}
		}
		return false;
	}

//â�� �Է� �� ������Ʈ
	public void warehouseupdate(int warehouseCode, int code, int count) {
		for (int i = 0; i < Warehouse.size(); i++) {
			if ((int) Warehouse.get(i).get(0) == warehouseCode) {
				for (int j = 0; j < ((ArrayList) Warehouse.get(i).get(4)).size(); j++) {
					if ((int) ((ArrayList) ((ArrayList) Warehouse.get(i).get(4)).get(j)).get(0) == code) {
						
						if((int) ((ArrayList) ((ArrayList) Warehouse.get(i).get(4)).get(j)).get(3) - count ==0) {
							((ArrayList) ((ArrayList) Warehouse.get(i).get(4)).get(j)).remove(3);
						
						}
						else {
							((ArrayList) ((ArrayList) Warehouse.get(i).get(4)).get(j)).set(3,
									(int) ((ArrayList) ((ArrayList) Warehouse.get(i).get(4)).get(j)).get(3) - count);
								
						}
					}
				}

			}
		}

	}
// ����� ������Ʈ
	public void warehouseupdate2(int warehouseCode, int code, int count) {
		for (int i = 0; i < Warehouse.size(); i++) {
			if ((int) Warehouse.get(i).get(0) == warehouseCode) {
				for (int j = 0; j < ((ArrayList) Warehouse.get(i).get(4)).size(); j++) {
					if ((int) ((ArrayList) ((ArrayList) Warehouse.get(i).get(4)).get(j)).get(0) == code) {
						
						if((int) ((ArrayList) ((ArrayList) Warehouse.get(i).get(4)).get(j)).get(3) + count ==0) {
							((ArrayList) ((ArrayList) Warehouse.get(i).get(4)).get(j)).remove(3);
						
						}
						else {
							((ArrayList) ((ArrayList) Warehouse.get(i).get(4)).get(j)).set(3,
									(int) ((ArrayList) ((ArrayList) Warehouse.get(i).get(4)).get(j)).get(3) +count);
								
						}
					}
				}

			}
		}

	}

	// �����Է� ��ǰ�ڵ�üũ
	public boolean orderCodeCheck(int code, int warehouseCode2) {
		boolean chk = true;

		for (int i = 0; i < Warehouse.size(); i++) {

			if ((int) ((ArrayList) Warehouse.get(i)).get(0) == warehouseCode2) {
				for (int j = 0; j < ((ArrayList) ((ArrayList) Warehouse.get(i)).get(4)).size(); j++) {
					if ((int) ((ArrayList) ((ArrayList) ((ArrayList) Warehouse.get(i)).get(4)).get(j)).get(0) == code) {
						chk = false;
					}
				}

			}

		}
		return chk;
	}

	// �����Է� ��ǰ ���� üũ
	public boolean productCountCheck(int warehouscode, int code, int sujucount) {

		for (int i = 0; i < Warehouse.size(); i++) {

			if ((int) ((ArrayList) Warehouse.get(i)).get(0) == warehouscode) {

				for (int j = 0; j < ((ArrayList) (ArrayList) Warehouse.get(i).get(4)).size(); j++) {

					if ((int) ((ArrayList) ((ArrayList) (ArrayList) Warehouse.get(i).get(4)).get(j)).get(0) == code) {

						if ((int) ((ArrayList) ((ArrayList) (ArrayList) Warehouse.get(i).get(4)).get(j))
								.get(3) >= sujucount) {

							return false;
						}
					}
				}

			}
		}
//		System.out.println("�ȳ�3");
		return true;
	}
}
