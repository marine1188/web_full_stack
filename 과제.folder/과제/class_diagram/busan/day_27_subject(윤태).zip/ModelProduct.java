package day_27_subject;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class ModelProduct {

	ArrayList<ArrayList> Products = new ArrayList<ArrayList>();
	ArrayList<ArrayList> RemoveProducts = new ArrayList<ArrayList>();
	int productCode;// ��ǰ�ڵ�
	String productName; // ��ǰ��
	int price; // ��ǰ�ܰ�
	Set warehousecode = new HashSet(); // â���ڵ�
	int count; // â���� ����ִ� ��ǰ����
	// �ʱ�ȭ

	public ModelProduct() throws IOException, ClassNotFoundException, StreamCorruptedException {
		boolean flag = true;
		File f = new File("product.txt");
		FileInputStream fis = null;
		ObjectInputStream bis = null;

		if (f.exists()) {
			try {
				fis = new FileInputStream(f);
				bis = new ObjectInputStream(fis);

				while (flag) {
					ArrayList temp = (ArrayList) bis.readObject();

					Products.add(temp);
					System.out.println();
				}

			} catch (EOFException e) {
				// ������ ���� �����ϸ� EOFException�� �߻�.
				// �� ���ܸ� ó�����ָ� ���������� ó���˴ϴ�!
				System.out.println();
				System.out.println("Success Product File!");
			} finally {

				bis.close();
			} // try end
		}
		flag = true;
		f = new File("productremove.txt");
		fis = null;
		bis = null;

		if (f.exists()) {
			
			try {
				fis = new FileInputStream(f);
				bis = new ObjectInputStream(fis);

				while (flag) {
					ArrayList temp = (ArrayList) bis.readObject();

					RemoveProducts.add(temp);
					System.out.println();
				}

			} catch (EOFException e) {
				// ������ ���� �����ϸ� EOFException�� �߻�.
				// �� ���ܸ� ó�����ָ� ���������� ó���˴ϴ�!
				System.out.println();
				System.out.println("Success ProductRemove File!");
			} finally {

				bis.close();
			} // try end
		}
	}

	public void ProductSave() throws IOException, ClassNotFoundException {

		if (Products.size() > 0) {
			System.out.println("��ǰ ������");
			new Controller().FileAdd("product.txt", Products);

		}
		if (RemoveProducts.size() > 0) {
			
			System.out.println("��ǰ ���� ������");
			new Controller().FileAdd("productremove.txt", RemoveProducts);

		}

	}

//��ǰ ���
	public void ProductAdd(int code, String name, int price, int count, int warehouseCode) {
		ArrayList temp = new ArrayList();

		if (Products.size() == 0) { //�ʱ������
			temp.add(code);
			temp.add(name);
			temp.add(price);
			temp.add(count);
			warehousecode.add(warehouseCode);
			temp.add(warehousecode);
			Products.add(temp);

		} else {
			temp.add(code);
			temp.add(name);
			temp.add(price);
			int c = Products.size();
			boolean flag = true;
			for (int i = 0; i < c; i++) {    
			
				if ((int) Products.get(i).get(0) == (code)) {   //���� �����ڵ尡�ִٸ�

				
				
					temp.add(count + (int) Products.get(i).get(3));
					warehousecode = (Set) Products.get(i).get(4);
					warehousecode.add(warehouseCode);
					temp.add(warehousecode);
					Products.set(i, temp);
					flag = false;
				}

			}
		
			if (flag) {  //�����ڵ尡���ٸ�
				

					
					temp.add(count);
				
						warehousecode = new HashSet();
						warehousecode.add(warehouseCode);

					
					temp.add(warehousecode);
					Products.add(temp);
				}
			
		}
	}

	

	// ��ǰ ���� ���
	public void ProductInfo(ArrayList productCount) {

		System.out.println();
		System.out.println();
		System.out.println(
				"=================================================================================================================================================================");

		System.out.printf("== %75s ��ǰ���� %71s==\n", " ", " ");
		System.out.println(
				"=================================================================================================================================================================");
		System.out.printf("%10s %20s %20s %20s %20s %15s \n", "��ǰ�ڵ�", "��ǰ�̸�", "����", "����", "��ü ����", "����â����ȣ");

		System.out.println(
				"=================================================================================================================================================================");
		for (int j = 0; j < productCount.size(); j++) {
				
			for (int i = 0; i < Products.size(); i++) {
				
				
				if (((ArrayList) productCount.get(j)).get(0).equals(Products.get(i).get(0))) {
					
					productCode = (int) Products.get(i).get(0);
					productName = (String) Products.get(i).get(1);
					price = (int) Products.get(i).get(2);
					count = (int) Products.get(i).get(3);
					warehousecode = (Set) Products.get(i).get(4);
					int allCount = (int) ((ArrayList) productCount.get(j)).get(2);

					System.out.printf("%10s %20s %20s %20s %20s %15s \n", productCode, productName, price, count,
							allCount, warehousecode);
				}
			}
		}
		System.out.println();

		System.out.println();
	}

// �����Է� ��ǰ ���� ������Ʈ

	public void productCountUpdate(int code, int sujucount, int warehouseCode2, Date date2) {

		for (int i = 0; i < Products.size(); i++) {

			if ((int) ((ArrayList) Products.get(i)).get(0) == code) {
				if ((int) ((ArrayList) Products.get(i)).get(3) >= sujucount) {

					if ((int) ((ArrayList) Products.get(i)).get(3) - sujucount == 0) {
						
						Products.get(i).add(warehouseCode2);
						Products.get(i).add(date2);
						RemoveProducts.add(Products.remove(i));
						

					} else {
						
						
						((ArrayList) Products.get(i)).set(3, (int) ((ArrayList) Products.get(i)).get(3) - sujucount);
						ArrayList temp3 = new ArrayList();
						temp3.addAll(Products.get(i));
						temp3.set(3,sujucount);
						temp3.add(warehouseCode2);
						temp3.add(date2);
						RemoveProducts.add(temp3);

					}

				}
			}
		}
//		System.out.println("�ȳ�3");

	}
	// ���ֵ�� ���
		public ArrayList removeUpdate(ArrayList temp) {
			String removeId =(String) temp.get(0);//���̵�
			int removeWarehouse=(int) temp.get(1); //â�� �ڵ�
			int removeCode=	(int) temp.get(2); // ��ǰ �ڵ� 
			int removeCount=(int) temp.get(3); // ��ǰ ����
			int removeSale=(int) temp.get(4); // ������
			Date removeDate= (Date) temp.get(5); // ���� �Է½ð�
			ArrayList temp2 = new ArrayList();
			for (int i = 0; i < RemoveProducts.size(); i++) {
				if((int)((ArrayList)RemoveProducts.get(i)).get(0)== removeCode) {
					
					if((int)((ArrayList)RemoveProducts.get(i)).get(3)== removeCount) {
						
						if(((ArrayList)RemoveProducts.get(i)).get(6).equals(removeDate)) {
							
							int wcode =(int)RemoveProducts.get(i).get(5); //���� ������ â���ڵ�
							
							temp2.addAll(RemoveProducts.get(i)); //��������
							
							RemoveProducts.get(i).remove(5);
							RemoveProducts.get(i).remove(5);
							boolean flag= true;
							for (int j = 0; j < Products.size(); j++) {
								if((int)(Products.get(j).get(0)) == (int)(RemoveProducts.get(i).get(0))) {
									
									Products.get(j).set(3,(int)Products.get(j).get(3) +(int)RemoveProducts.get(i).get(3));
								flag=false;
								}
							}
							if(flag) {
								
							Products.add(RemoveProducts);
							}
							RemoveProducts.remove(i);
							
							return temp2;
						}
						
					}
				}
			}
			return temp2;
			
		}

}
