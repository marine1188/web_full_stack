package day_27_subject;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.StreamCorruptedException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Set;

public class ModelOrders {
	int orderNo = 0;// ���ֹ�ȣ
	int count; // ����
	String id; // ������ ���̵�
	int sale; // ������
	int statusCode; // �����ڵ� [0 :�Է� 1: ��� 2: ���] ����

	ArrayList orders = new ArrayList();
	ArrayList temp;

	// ���� �Է� ���� ����
	public Date orderAdd(int warehouseocde,int code, int count, int sujusale,  String id) {
	
		temp = new ArrayList();
		temp.add(this.orderNo);
		temp.add(id); //���̵�
		temp.add(warehouseocde); //â�� �ڵ�
		temp.add(code); //��ǰ�ڵ�
		temp.add(count); //��ǰ����
		temp.add(sujusale); //������
		temp.add(new Date()); //���� �Է½ð�
		temp.add(0); //�Է»��� 
		orders.add(temp);
		orderNo++;
		return (Date) temp.get(6);
	}
	//���� ��� ���� ����
	public boolean orderEnroll(int no) {
		for (int i = 0; i < orders.size(); i++) {
			if((int)((ArrayList)orders.get(i)).get(0)==no) {
				((ArrayList)orders.get(i)).set(7,1);
				return true;
			}
		}
		return false;
	}
	
	//��� -> ��� ���
		public ArrayList orderRemove(int choice2) {
			for (int i = 0; i < orders.size(); i++) {
				if((int)((ArrayList)orders.get(i)).get(0)==choice2) {
					if((int)((ArrayList)orders.get(i)).get(7)==1) {
						temp=new ArrayList();
						temp.add(((ArrayList)orders.get(i)).get(1));//���̵�
						temp.add(((ArrayList)orders.get(i)).get(2)); //â�� �ڵ�
						temp.add(((ArrayList)orders.get(i)).get(3)); // ��ǰ �ڵ� 
						temp.add(((ArrayList)orders.get(i)).get(4)); // ��ǰ ����
						temp.add(((ArrayList)orders.get(i)).get(5)); // ������
						temp.add(((ArrayList)orders.get(i)).get(6)); // ���� �Է½ð�
						orders.remove(i);
						return temp;
					}
				}
			}
			return new ArrayList();
			
		}
		
		//�Է�-> �Է� ���
		public ArrayList orderRemove2(int choice2) {
			for (int i = 0; i < orders.size(); i++) {
				if((int)((ArrayList)orders.get(i)).get(0)==choice2) {
					if((int)((ArrayList)orders.get(i)).get(7)==0) {
						temp=new ArrayList();
						temp.add(((ArrayList)orders.get(i)).get(1));//���̵�
						temp.add(((ArrayList)orders.get(i)).get(2)); //â�� �ڵ�
						temp.add(((ArrayList)orders.get(i)).get(3)); // ��ǰ �ڵ� 
						temp.add(((ArrayList)orders.get(i)).get(4)); // ��ǰ ����
						temp.add(((ArrayList)orders.get(i)).get(5)); // ������
						temp.add(((ArrayList)orders.get(i)).get(6)); // ���� �Է½ð�
						orders.remove(i);
						return temp;
					}
				}
			}
			return new ArrayList();
			
		}
////Ȯ���Լ���
	
	


	///
	
	
//�������
	public ModelOrders() throws IOException, ClassNotFoundException, StreamCorruptedException {
		boolean flag = true;
		File f = new File("orders.txt");
		FileInputStream fis = null;
		ObjectInputStream bis = null;

		if (f.exists()) {
			ArrayList temp=null;
			try {
				fis = new FileInputStream(f);
				bis = new ObjectInputStream(fis);
				
				while (flag) {
					temp = (ArrayList) bis.readObject();

					orders.add(temp);
					System.out.println("");
					
//					this.orderNo= (int)((ArrayList)temp.get(temp.size()-1)).get(0);
				}

			} catch (EOFException e) {
				// ������ ���� �����ϸ� EOFException�� �߻�.
				// �� ���ܸ� ó�����ָ� ���������� ó���˴ϴ�!
				System.out.println();
				System.out.println("Success Order File!");
			} finally {
				this.orderNo = (int)temp.get(0)+1;
				bis.close();
			} // try end
		}
	}
	
	public void OrdersSave() throws IOException, ClassNotFoundException {

	
		if (orders.size() > 0) {
			System.out.println("���� ������");
			new Controller().FileAdd("orders.txt", orders);

		}

	}
//////////////////
	//���� �Է� ��ǰ ���
	public void info() {
		System.out.println();
		System.out.println();
		System.out.println(
				"=================================================================================================================================================================");

		System.out.printf("== %75s �����Է»�ǰ���� %71s==\n", " ", " ");
		System.out.println(
				"=================================================================================================================================================================");
		System.out.printf("%10s %10s %20s %20s %20s %20s %15s \n","��ȣ", "���̵�", "â���ڵ�", "��ǰ�ڵ�", "����", "������", "���� �Է� �ð�");

		System.out.println(
				"=================================================================================================================================================================");
	
			
			for (int i = 0; i < orders.size(); i++) {
				
				if ((int)((ArrayList) orders.get(i)).get(7) ==0) {
					int printOrderno = (int)((ArrayList) orders.get(i)).get(0);
					String printId =(String)((ArrayList) orders.get(i)).get(1);
					int printWarehouseCode=(int)((ArrayList) orders.get(i)).get(2);
					int printCode =(int)((ArrayList) orders.get(i)).get(3);
					int printCount= (int)((ArrayList) orders.get(i)).get(4);
					int printSujuSale =(int)((ArrayList) orders.get(i)).get(5);
					Date printDate = (Date)((ArrayList) orders.get(i)).get(6);
					
					String printDate2=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(printDate);
					System.out.printf("%10d %20s %20d %20d %20d %30s%% %20s\n", printOrderno, printId, printWarehouseCode, printCode,
							printCount, printSujuSale ,  printDate2);
				}
			}
		
	
		System.out.println();

		System.out.println();
		
	}
	//���� �Է� ��ǰ ��� (���̵�)
	public void info2(String id) {
		System.out.println();
		System.out.println();
		System.out.println(
				"=================================================================================================================================================================");

		System.out.printf("== %75s �����Է»�ǰ���� %71s==\n", " ", " ");
		System.out.println(
				"=================================================================================================================================================================");
		System.out.printf("%10s %10s %20s %20s %20s %20s %15s \n","��ȣ", "���̵�", "â���ڵ�", "��ǰ�ڵ�", "����", "������", "���� �Է� �ð�");

		System.out.println(
				"=================================================================================================================================================================");
	
			
			for (int i = 0; i < orders.size(); i++) {
				
				if ((int)((ArrayList) orders.get(i)).get(7) ==0 && ((ArrayList) orders.get(i)).get(1).equals(id)) {
					int printOrderno = (int)((ArrayList) orders.get(i)).get(0);
					String printId =(String)((ArrayList) orders.get(i)).get(1);
					int printWarehouseCode=(int)((ArrayList) orders.get(i)).get(2);
					int printCode =(int)((ArrayList) orders.get(i)).get(3);
					int printCount= (int)((ArrayList) orders.get(i)).get(4);
					int printSujuSale =(int)((ArrayList) orders.get(i)).get(5);
					Date printDate = (Date)((ArrayList) orders.get(i)).get(6);
					
					String printDate2=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(printDate);
					System.out.printf("%10d %20s %20d %20d %20d %30s%% %20s\n", printOrderno, printId, printWarehouseCode, printCode,
							printCount, printSujuSale ,  printDate2);
				}
			}
		
		System.out.println();

		System.out.println();
		
	}	
	//������Ȳ ���� ���
		public void infoAll() {
			System.out.println(
					"=================================================================================================================================================================");

			System.out.printf("== %75s �����Է»�ǰ���� %71s==\n", " ", " ");
			System.out.println(
					"=================================================================================================================================================================");
			System.out.printf("%10s %10s %20s %20s %20s %20s %15s \n","��ȣ", "���̵�", "â���ڵ�", "��ǰ�ڵ�", "����", "������", "���� �Է� �ð�");

			System.out.println(
					"=================================================================================================================================================================");
		
				int chk=0;
				for (int i = 0; i < orders.size(); i++) {
					
					if ((int)((ArrayList) orders.get(i)).get(7) ==0) {
						int printOrderno = (int)((ArrayList) orders.get(i)).get(0);
						String printId =(String)((ArrayList) orders.get(i)).get(1);
						int printWarehouseCode=(int)((ArrayList) orders.get(i)).get(2);
						int printCode =(int)((ArrayList) orders.get(i)).get(3);
						int printCount= (int)((ArrayList) orders.get(i)).get(4);
						int printSujuSale =(int)((ArrayList) orders.get(i)).get(5);
						Date printDate = (Date)((ArrayList) orders.get(i)).get(6);
						
						String printDate2=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(printDate);
						System.out.printf("%10d %20s %20d %20d %20d %30s%% %20s\n", printOrderno, printId, printWarehouseCode, printCode,
								printCount, printSujuSale ,  printDate2);
						chk++;
					}
				}
				if(chk==0)
					System.out.printf("%50s","�Է»�ǰ����");
				System.out.println();
				System.out.println();
			System.out.println(
					"=================================================================================================================================================================");

			System.out.printf("== %75s ���ֵ�ϻ�ǰ���� %71s==\n", " ", " ");
			System.out.println(
					"=================================================================================================================================================================");
			System.out.printf("%10s %10s %20s %20s %20s %20s %15s \n","��ȣ", "���̵�", "â���ڵ�", "��ǰ�ڵ�", "����", "������", "���� �Է� �ð�");

			System.out.println(
					"=================================================================================================================================================================");
		
				chk=0;
				for (int i = 0; i < orders.size(); i++) {
					
					if ((int)((ArrayList) orders.get(i)).get(7) ==1) {
						int printOrderno = (int)((ArrayList) orders.get(i)).get(0);
						String printId =(String)((ArrayList) orders.get(i)).get(1);
						int printWarehouseCode=(int)((ArrayList) orders.get(i)).get(2);
						int printCode =(int)((ArrayList) orders.get(i)).get(3);
						int printCount= (int)((ArrayList) orders.get(i)).get(4);
						int printSujuSale =(int)((ArrayList) orders.get(i)).get(5);
						Date printDate = (Date)((ArrayList) orders.get(i)).get(6);
						
						String printDate2=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(printDate);
						System.out.printf("%10d %20s %20d %20d %20d %30s%% %20s\n", printOrderno, printId, printWarehouseCode, printCode,
								printCount, printSujuSale ,  printDate2);
					}
				}
				if(chk==0)
					System.out.printf("%50s","��ϻ�ǰ���� ");
				System.out.println();
				System.out.println();
				
			
		}
		//���� ��ü ��ǰ ��� (���̵� )
		public void infoAll2(String id) {
			System.out.println(
					"=================================================================================================================================================================");

			System.out.printf("== %75s �����Է»�ǰ���� %71s==\n", " ", " ");
			System.out.println(
					"=================================================================================================================================================================");
			System.out.printf("%10s %10s %20s %20s %20s %20s %15s \n","��ȣ", "���̵�", "â���ڵ�", "��ǰ�ڵ�", "����", "������", "���� �Է� �ð�");

			System.out.println(
					"=================================================================================================================================================================");
		
				int chk=0;
				for (int i = 0; i < orders.size(); i++) {
					
					if ((int)((ArrayList) orders.get(i)).get(7) ==0  && ((ArrayList) orders.get(i)).get(1).equals(id)) {
						int printOrderno = (int)((ArrayList) orders.get(i)).get(0);
						String printId =(String)((ArrayList) orders.get(i)).get(1);
						int printWarehouseCode=(int)((ArrayList) orders.get(i)).get(2);
						int printCode =(int)((ArrayList) orders.get(i)).get(3);
						int printCount= (int)((ArrayList) orders.get(i)).get(4);
						int printSujuSale =(int)((ArrayList) orders.get(i)).get(5);
						Date printDate = (Date)((ArrayList) orders.get(i)).get(6);
						
						String printDate2=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(printDate);
						System.out.printf("%10d %20s %20d %20d %20d %30s%% %20s\n", printOrderno, printId, printWarehouseCode, printCode,
								printCount, printSujuSale ,  printDate2);
						chk++;
					}
				}
				if(chk==0)
					System.out.printf("%50s","�Է»�ǰ����");
				System.out.println();
				System.out.println();
			System.out.println(
					"=================================================================================================================================================================");

			System.out.printf("== %75s ���ֵ�ϻ�ǰ���� %71s==\n", " ", " ");
			System.out.println(
					"=================================================================================================================================================================");
			System.out.printf("%10s %10s %20s %20s %20s %20s %15s \n","��ȣ", "���̵�", "â���ڵ�", "��ǰ�ڵ�", "����", "������", "���� �Է� �ð�");

			System.out.println(
					"=================================================================================================================================================================");
		
				chk=0;
				for (int i = 0; i < orders.size(); i++) {
					
					if ((int)((ArrayList) orders.get(i)).get(7) ==1  && ((ArrayList) orders.get(i)).get(1).equals(id)) {
						int printOrderno = (int)((ArrayList) orders.get(i)).get(0);
						String printId =(String)((ArrayList) orders.get(i)).get(1);
						int printWarehouseCode=(int)((ArrayList) orders.get(i)).get(2);
						int printCode =(int)((ArrayList) orders.get(i)).get(3);
						int printCount= (int)((ArrayList) orders.get(i)).get(4);
						int printSujuSale =(int)((ArrayList) orders.get(i)).get(5);
						Date printDate = (Date)((ArrayList) orders.get(i)).get(6);
						
						String printDate2=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(printDate);
						System.out.printf("%10d %20s %20d %20d %20d %30s%% %20s\n", printOrderno, printId, printWarehouseCode, printCode,
								printCount, printSujuSale ,  printDate2);
						chk++;
					}
				}
				if(chk==0)
					System.out.printf("%50s","��ϻ�ǰ���� ");
				System.out.println();
				System.out.println();
			
		}
		
	//���� ��� ��ǰ ���
	public void infoEnroll() {
		System.out.println();
		System.out.println();
		System.out.println(
				"=================================================================================================================================================================");

		System.out.printf("== %75s ���ֵ�ϻ�ǰ���� %71s==\n", " ", " ");
		System.out.println(
				"=================================================================================================================================================================");
		System.out.printf("%10s %10s %20s %20s %20s %20s %15s \n","��ȣ", "���̵�", "â���ڵ�", "��ǰ�ڵ�", "����", "������", "���� �Է� �ð�");

		System.out.println(
				"=================================================================================================================================================================");
	
			
			for (int i = 0; i < orders.size(); i++) {
				
				if ((int)((ArrayList) orders.get(i)).get(7) ==1) {
					int printOrderno = (int)((ArrayList) orders.get(i)).get(0);
					String printId =(String)((ArrayList) orders.get(i)).get(1);
					int printWarehouseCode=(int)((ArrayList) orders.get(i)).get(2);
					int printCode =(int)((ArrayList) orders.get(i)).get(3);
					int printCount= (int)((ArrayList) orders.get(i)).get(4);
					int printSujuSale =(int)((ArrayList) orders.get(i)).get(5);
					Date printDate = (Date)((ArrayList) orders.get(i)).get(6);
					
					String printDate2=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(printDate);
					System.out.printf("%10d %20s %20d %20d %20d %30s%% %20s\n", printOrderno, printId, printWarehouseCode, printCode,
							printCount, printSujuSale ,  printDate2);
				}
			}
	
		System.out.println();

		System.out.println();
		
	}
	//������üũ�Լ�
		public boolean check(int choice2) {
			for (int i = 0; i < orders.size(); i++) {
				if( (int)((ArrayList)orders.get(i)).get(0)==choice2) {
					return true;
				}
			}
			System.out.println("���� ��ȣ�Դϴ�.");
			return false;
		}
		//�Է����üũ�Լ�
		public boolean check2(int choice2,String id) {
			for (int i = 0; i < orders.size(); i++) {
				if( (int)((ArrayList)orders.get(i)).get(0)==choice2 &&((ArrayList)orders.get(i)).get(1).equals(id)) {
					return true;
				}
			}
			System.out.println("���� ��ȣ�Դϴ�.");
			return false;
		}
	
	
	

}
