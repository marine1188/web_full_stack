package homework;

public class Stock {
	private int stockCount = 100;

	public int getStockCount() {
		return stockCount;
	}
}
