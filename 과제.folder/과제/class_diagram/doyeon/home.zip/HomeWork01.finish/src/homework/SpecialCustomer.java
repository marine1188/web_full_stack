package homework;

public class SpecialCustomer {
	private int spNum = 1;

	public int getSpNum() {
		return spNum;
	}
}
