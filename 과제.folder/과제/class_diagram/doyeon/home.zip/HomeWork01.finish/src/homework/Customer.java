package homework;

class Customer extends SpecialCustomer {
	private static Integer cusNum = 1;
	private String cusName;
	private String cusAddress;
	private String cusPhone;
	
	public String getCusNum() {
		String cusNumS = cusNum.toString();
		return cusNumS;
	}
	public String getCusName() {
		++cusNum;
		return cusName;
	}
	public String getCusAddress() {
		return cusAddress;
	}
	public String getCusPhone() {
		return cusPhone;
	}
	
	public void setCusNum(Integer cusNum) {
		this.cusNum = cusNum;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public void setCusAddress(String cusAddress) {
		this.cusAddress = cusAddress;
	}
	public void setCusPhone(String cusPhone) {
		this.cusPhone = cusPhone;
	}
	
	public String[] setCusInfo(){
		String[] info = new String[5];
		for(int i = 0; i < info.length; i++){
			switch(i){
			case 0: info[i] = getCusNum();
				break;
			case 1: info[i] = getCusName();
				break;
			case 2: info[i] = getCusAddress();
				break;
			case 3: info[i] = getCusPhone();
				break;
			case 4: if(cusNum == getSpNum()){
						info[i] = "True";
					}else{
						info[i] = "False";
					}
				break;
			}
		}
		return info;
	}
	
}
