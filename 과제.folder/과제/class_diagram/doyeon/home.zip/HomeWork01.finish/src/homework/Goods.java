package homework;

public class Goods {
	private int[] goodsNum = {11, 25, 133};		//��ǰ �ڵ�
	private String[] goodsName = {"Com", "Tv", "Radio"};	//��ǰ��
	private int[] goodsCost = {1200000, 800000, 25000};		//�ܰ�
	
	private int goodsSelectNum = 0;
	
	public int getGoodsNum() {
		return goodsNum[goodsSelectNum];
	}
	public String[] getGoodsNameLength(){
		return goodsName;
	}
	public String getGoodsName() {
		return goodsName[goodsSelectNum];
	}
	public String getGoodsNameChk(int n){
		return goodsName[n];
	}
	public int getGoodsCost() {
		return goodsCost[goodsSelectNum];
	}
	
	public void setGoodsSelectNum(int num){
		goodsSelectNum = num;
	}
	
	
}
