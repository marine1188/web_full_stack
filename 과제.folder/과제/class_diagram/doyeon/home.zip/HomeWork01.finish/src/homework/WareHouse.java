package homework;

public class WareHouse {
	private String wareHouseName = "OOâ��";
	private String wareHouseAddres = "��⵵ ���ν� �跮�嵿";
	private String wareHousePhone = "010 XXXX 1234";
	
	public String[] getWareHouseInfo(){
		String[] info = new String[3];
		for(int i = 0; i < info.length; i++){
			switch(i){
			case 0: info[i] = getWareHouseName();
				break;
			case 1: info[i] = getWareHouseAddres();
				break;
			case 2: info[i] = getWareHousePhone();
				break;
			}
		}
		return info;
	}
	
	public String getWareHouseName() {
		return wareHouseName;
	}
	public String getWareHouseAddres() {
		return wareHouseAddres;
	}
	public String getWareHousePhone() {
		return wareHousePhone;
	}
	
	
}
