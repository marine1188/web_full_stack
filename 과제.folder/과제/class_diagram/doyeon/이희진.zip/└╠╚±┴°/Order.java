package day12_Problem_ClassDiagram;

import java.util.GregorianCalendar;

//����
public class Order {
	//���ֹ�ȣ
	private int id;
	//���ֳ�¥
	private GregorianCalendar date;
	//���ָ���
	private OrderInfo[] orderInfos;
	// ����
	private Customer customer;
	//���ָ� ����Ѵ�
	public Order() {
	}
	public Order(int id, OrderInfo[] orderInfos, Customer customer) {
		this.id = id;
		this.date = getGDate();
		this.orderInfos = orderInfos;
		this.customer = customer;
	}

	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public OrderInfo[] getOrderInfos() {
		return orderInfos;
	}
	public void setOrderInfos(OrderInfo[] orderInfos) {
		this.orderInfos = orderInfos;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public GregorianCalendar getDate() {
		return date;
	}
	public void setDate(GregorianCalendar date) {
		this.date = date;
	}
	
	//���ֳ�¥�� ����Ѵ�
	private GregorianCalendar getGDate() {
		return new GregorianCalendar();
	}
}
