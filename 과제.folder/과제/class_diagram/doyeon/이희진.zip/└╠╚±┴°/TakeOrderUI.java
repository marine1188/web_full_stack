package day12_Problem_ClassDiagram;

import java.util.Calendar;
import java.util.Scanner;

public class TakeOrderUI {
	static Item[] item = new Item[5];
	static Customer[] customer = new Customer[5];
	static Stock[] stock = new Stock[item.length];
	static Storage[] storage = new Storage[stock.length];
	static Order[] orders = new Order[100];
	static int order_count = 0;
	static {
		// ��ǰ�ʱ�ȭ
		for (int i = 0; i < item.length; i++) {
			item[i] = new Item();
			item[i].setCode(i + 100);
			item[i].setName("��ǰ" + i);
			item[i].setPrice(1000 * (i+1));
		}
		// �����ʱ�ȭ
		for (int i = 0; i < customer.length; i++) {
			customer[i] = new Customer();
			customer[i].setId(i + 1000);
			customer[i].setName("����" + i);
			customer[i].setAddress("�ּ�" + i);
			customer[i].setTel("��ȭ��ȣ" + i);
		}
		// ����ʱ�ȭ
		for (int i = 0; i < stock.length; i++) {
			stock[i] = new Stock();
			stock[i].setItem(item[i]);
			stock[i].setTotal((i+1)*100);
		}
		// â���ʱ�ȭ
		for (int i = 0; i < stock.length; i++) {
			storage[i] = new Storage();
			storage[i].setName("â��" + i);
			storage[i].setAddress("â����ġ" + i);
			storage[i].setTel("000-000-000" + i);
			storage[i].setStock(stock[i]);
		}
	}

	// ���� �Է��Ѵ�(��������)
	public Order input(Scanner scan) {
		// ���ֹ�ȣ, ���ֳ�¥ X
		// 1. ��ǰ�ڵ� �Է� 100~104
		// 2. ���ּ���, ������ �Է�
		// 3. ������ȣ �Է� 1000~1004
		
		int code, amount, discountRate, id;	
		int indexOfCode, indexOfID;
		int count = 0;
		OrderInfo[] orderInfos = new OrderInfo[stock.length];
		while(true) {
			System.out.print("��ǰ�ڵ��Է�(100~104): ");
			code = scan.nextInt();
			indexOfCode = checkItem(code);
	
			System.out.print("���ּ��� �Է�: ");
			amount = scan.nextInt();		
			
			System.out.print("������ �Է�: ");
			discountRate = scan.nextInt();
			
			orderInfos[count] = new OrderInfo(amount, discountRate, item[indexOfCode]);
			count++;
			System.out.println("�ݺ�? 1.no 2.yes");
			if(scan.nextInt() == 1 ) break;
		}
		System.out.print("������ȣ �Է�(1000~1004): ");
		id = scan.nextInt();		
		indexOfID = checkCustomer(id);
		Order order = new Order(0, orderInfos, customer[indexOfID]);

		return order;
	}

	// ���� ����Ѵ�
	public void create(Order order) {
		order.setId(order_count);
		orders[order_count] = order;
		order_count++;
		int total = stock[order.getId()].getTotal();
		stock[order.getId()].setTotal(total-1);
	}

	// ���� ����Ѵ�
	public void cancel(int id) {
		for(int i = id; i<=order_count; i++) {
			orders[i] = orders[i+1];	
		}
		order_count--;
		OrderInfo[] orderInfos = orders[id].getOrderInfos();
		for(int i = 0; i<orderInfos.length; i++) {
			int itemcode = orderInfos[i].getItem().getCode();
			int total = stock[itemcode].getTotal();
			stock[itemcode].setTotal(total+1);
		}
	}

	// ��ǰ üũ
	public int checkItem(int code) {
		for (int i = 0; i < item.length; i++) {
			if (item[i].getCode() == code) {
				return i;
			}
		}
		return -1;
	}

	// ���� üũ
	public int checkCustomer(int id) {
		for (int i = 0; i < customer.length; i++) {
			if (customer[i].getId() == id) {
				return i;
			}
		}
		return -1;
	}
	public static int searchTotal(int code) {
		for(int i = 0; i<item.length; i++) {
			if(code == item[i].getCode())
				return i;
		}
		return -1;
	}
	
	public static void main(String[] args) {
		
		TakeOrderUI ui = new TakeOrderUI();
		Order order = ui.input(new Scanner(System.in));
		ui.create(order);
		for(int i = 0; i<order_count; i++) {
			System.out.println( ""
					+ " \t���ֹ�ȣ: "+ orders[i].getId() 
					+ " \t\t�����̸�: " + orders[i].getCustomer().getName() 
					+ " \t\t��¥: " + orders[i].getDate().get(Calendar.YEAR) + "��"
									+ (orders[i].getDate().get(Calendar.MONTH)+1) + "��"
									+ orders[i].getDate().get(Calendar.DATE) +"��");
			OrderInfo[] orderinfo = orders[i].getOrderInfos();
			for(int j = 0;  orderinfo[j] != null; j++) {
				Item temp = orderinfo[j].getItem();
				int total = stock[searchTotal(temp.getCode())].getTotal();
				System.out.println("" 
						+ " \t��ǰ�̸�: " + temp.getName()
						+ " \t��ǰ����: " + temp.getPrice() + "��"
						+ " \t\t���ּ���: " + orderinfo[j].getAmount() 
						+ " \t\t��ǰ���: " + total);
			}//for j
		}//for i
	}// main
}// TakeOrderUI
