package day12_Problem_ClassDiagram;

public class SpecialCustomer extends Customer {
	
}
