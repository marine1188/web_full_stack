package soojoo.order;

public class Stuck {
	
	private int stuck;

	public int getStuck() {
		return stuck;
	}

	public void setStuck(int stuck) {
		this.stuck = stuck;
	}
	
}
