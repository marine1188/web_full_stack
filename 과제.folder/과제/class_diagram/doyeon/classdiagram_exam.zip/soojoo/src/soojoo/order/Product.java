package soojoo.order;

public class Product {
		
	private int pNum;
	private String pName;
	private int pPrice;
	
	public Product(int pNum, String pName, int pPrice) {
		this.pNum = pNum;
		this.pName = pName;
		this.pPrice = pPrice;
	}
	public int getpNum() {
		return pNum;
	}
	public void setpNum(int pNum) {
		this.pNum = pNum;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public int getpPrice() {
		return pPrice;
	}
	public void setpPrice(int pPrice) {
		this.pPrice = pPrice;
	}
		
}
