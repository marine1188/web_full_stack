package soojoo.order;

import java.util.ArrayList;
import java.util.Date;

public class Account {	//���ָ���
	
	private int orderCount;
	private double discount;
	
	public Account(int orderCount, double discount) {
		this.orderCount = orderCount;
		this.discount = discount;
	}
	
	public int getOrderCount() {
		return orderCount;
	}
	public void setOrderCount(int orderCount) {
		this.orderCount = orderCount;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	
	public void RegistAccount(Account ac) {
		
		ArrayList<Account> alist = new ArrayList<Account>();
		
		alist.add(ac);
		
		System.out.println("���ָ����� ����Ѵ�(���ָ�������)");
		System.out.println("=================================���� ���� ����==================================");
		
		ArrayList<Product> plist = CopyOfOrderMain.productInfo;
		
		for (int i = 0; i < alist.size(); i++) {
		
			System.out.println("��ǰ ���� : " + alist.get(i).getOrderCount() + " / "
					+ "���η� : " + alist.get(i).getDiscount() + " / "
					+ "��ǰ�� : " + plist.get(Integer.parseInt(CopyOfOrderMain.orInfo.get(i))).getpName() + " / "
					+ "������ : " + plist.get(Integer.parseInt(CopyOfOrderMain.orInfo.get(i))).getpPrice()
										* alist.get(i).getOrderCount() 
										* alist.get(i).getDiscount()
			);
			
		}
		
		System.out.println("\n\n\n\n\n\n");
		CopyOfOrderMain.menu();
		
	}
	
}
