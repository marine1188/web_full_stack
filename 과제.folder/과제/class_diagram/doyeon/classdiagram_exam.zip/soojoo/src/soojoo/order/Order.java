package soojoo.order;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Order {
	
	private int oNum;
	private Date oDate;
	private Account account;
	
	public Order() {
		// TODO Auto-generated constructor stub
	}
	
	public Order(int oNum, Date oDate) {
		this.oNum = oNum;
		this.oDate = oDate;
	}

	public int getoNum() {
		return oNum;
	}

	public void setoNum(int oNum) {
		this.oNum = oNum;
	}

	public Date getoDate() {
		return oDate;
	}

	public void setoDate(Date oDate) {
		this.oDate = oDate;
	}
	
	public Account getAccount() {
		return account;
	}

	public void setAccount(int co, double discount) {
		this.account = new Account(co, discount);
	}

	static ArrayList<Order> olist = new ArrayList<Order>();
	int count = 0;
	
	public void SetOrder(Order od) {
		
		System.out.println("���ֵ���Ѵ�(��������)");
		
		olist.add(od);
		
		System.out.println("���� ��ȣ : " + olist.get(count).getoNum() + " / "
					
					+ "���� �̸� : " + CopyOfOrderMain.customerInfo.get(olist.get(count).getoNum()).getcName()
					+ " / "
					+ "���� ��ȣ : " + CopyOfOrderMain.customerInfo.get(olist.get(count).getoNum()).getcPhone()
					+ " / "
					+ "���� �ּ� : " + CopyOfOrderMain.customerInfo.get(olist.get(count).getoNum())
							.getcAddress() + " / "
					
					+ "���� �Է� ��¥ : " + olist.get(count).getoDate() + " / "
					+ "���ָ��� ��ü �ּ� : " + olist.get(count).getAccount().toString()
					);
		
		System.out.println("====================================��ϿϷ�===================================");
		
		System.out.println("���� ��� ��¥ :" + getDate());
		
		count++;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("���ָ����� ����Ͻðڽ��ϱ�?");
		System.out.println("1. �� 2. ���ֵ�� �޴�");
		switch (sc.nextInt()) {
			case 1:
				account.RegistAccount(account);
				break;
				
			case 2:
				CopyOfOrderMain om = new CopyOfOrderMain();
				om.menu();
				break;
				
			default:
				break;
				
		}
		
	}
	
	private String getDate() {
		
		System.out.println("���ֳ�¥�� ����Ѵ�():���ֳ�¥");
		
		return String.valueOf(getoDate());
		
	}
	
	
}
