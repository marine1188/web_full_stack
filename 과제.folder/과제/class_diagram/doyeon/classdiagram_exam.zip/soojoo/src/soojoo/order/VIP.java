package soojoo.order;

public class VIP extends Customer{

	private int member;
	
	public VIP(int num, String name, String address, String phone) {
		super(num, name, address, phone);
		this.member = num;
	}

	public int getMember() {
		return member;
	}

	public void setMember(int member) {
		this.member = member;
	}
		
}
