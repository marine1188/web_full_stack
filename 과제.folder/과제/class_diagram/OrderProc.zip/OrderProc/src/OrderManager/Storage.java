package OrderManager;

public class Storage {
	protected String Storage_name;
	protected String Storage_Add;
	protected String Storage_Tell;

}
